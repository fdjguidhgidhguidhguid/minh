# Đi ốt vê mót

Tool ddos vmos =))

# LƯU Ý
Lấy làm của riêng, hoặc viết lại (= cách decode lấy source) thì ráng ghi nguồn vào nhé. Vì đây không phải open source.

Powered by: https://github.com/hectran12
## Description

Idk

## Getting Started

### Installing

* Cài nodejs bản mới nhất :D
  
* Sau đó vào folder tool gõ "npm i" để tiến hành cài các thư viện cần thiết

## Hướng dẫn sài pc

npm iㅤㅤㅤㅤㅤㅤ// để install modul 

node buffㅤㅤㅤㅤ// để chạy tool

nhập số lượn threat 1-2000 tùy theo cấu hình máy bạn

## Hướng dẫn trên termux

nhập từng lệnh mỗi lệnh 1 dòng

apt update

apt upgrade 

pkg install git 

pkg install nodejs 

git clone https://github.com/nivagameco/ddov

cd ddov 

npm i

node buff

1000

"# ddov" 
